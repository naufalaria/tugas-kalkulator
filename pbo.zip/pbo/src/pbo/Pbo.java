/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pbo;

/**
 *
 * @author RIFKI NAUFAL ARIA
 */
public class Pbo {
     public static int penjumlahan(int a, int b){
     return a+b;
     }
     public static int pengurangan(int a, int b){
     return a-b;
     }
     public static int pembagian(int a, int b){
     return a/b;
     }
     public static int perkalian(int a, int b){
     return a*b;
     }
     public static int sisabagi(int a, int b){
     return a%b;
     }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    System.out.println("hasil penjumlahan: " + penjumlahan(10, 10));
    System.out.println("hasil pengurangan: " + pengurangan(50, 25));
    System.out.println("hasil pembagian: " + pembagian(100, 2));
    System.out.println("hasil perkalian: " + perkalian(50, 2));
    System.out.println("hasil sisa bagi: " + sisabagi(10, 3));
    }
    }
